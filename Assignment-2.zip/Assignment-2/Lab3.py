import RPi.GPIO as GPIO
import time

# Define GPIO pins
red_pin = 23
green_pin = 24
blue_pin = 16

# Define Morse code dictionary for each character
morse_code = {
    'A': ['.','-'],
    'B': ['-','.','.','.'],
    'C': ['-','.','-','.'],
    'D': ['-','.','.'],
    'E': ['.'],
    'F': ['.','.','-','.'],
    'G': ['-','-','.'],
    'H': ['.','.','.','.'],
    'I': ['.','.'],
    'J': ['.','-','-','-'],
    'K': ['-','.','-'],
    'L': ['.','-','.','.'],
    'M': ['-','-'],
    'N': ['-','.'],
    'O': ['-','-','-'],
    'P': ['.','-','-','.'],
    'Q': ['-','-','.','-'],
    'R': ['.','-','.'],
    'S': ['.','.','.'],
    'T': ['-'],
    'U': ['.','.','-'],
    'V': ['.','.','.','-'],
    'W': ['.','-','-'],
    'X': ['-','.','.','-'],
    'Y': ['-','.','-','-'],
    'Z': ['-','-','.','.'],
    '0': ['-','-','-','-','-'],
    '1': ['.','-','-','-','-'],
    '2': ['.','.','-','-','-'],
    '3': ['.','.','.','-','-'],
    '4': ['.','.','.','.','-'],
    '5': ['.','.','.','.','.'],
    '6': ['-','.','.','.','.'],
    '7': ['-','-','.','.','.'],
    '8': ['-','-','-','.','.'],
    '9': ['-','-','-','-','.']
}

# Set up GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(red_pin, GPIO.OUT)
GPIO.setup(green_pin, GPIO.OUT)
GPIO.setup(blue_pin, GPIO.OUT)

# Set initial LED states
GPIO.output(red_pin, GPIO.LOW)
GPIO.output(green_pin, GPIO.LOW)
GPIO.output(blue_pin, GPIO.LOW)

# Define dot, dash, and character intervals
dot_interval = 0.2  # Time in seconds
dash_interval = 3 * dot_interval
char_interval = 7 * dot_interval

def send_morse_code(code):
    for symbol in code:
        if symbol == '.':
            GPIO.output(red_pin, GPIO.HIGH)  # Red LED on
            time.sleep(dot_interval)
            GPIO.output(red_pin, GPIO.LOW)  # Red LED off
        elif symbol == '-':
            GPIO.output(blue_pin, GPIO.HIGH)  # Blue LED on
            time.sleep(dash_interval)
            GPIO.output(blue_pin, GPIO.LOW)  # Blue LED off
        time.sleep(dot_interval)  # Pause between symbols

def send_message(message):
    for char in message:
        if char == ' ':
            time.sleep(char_interval)  # Pause between words
        elif char.upper() in morse_code:
            code = morse_code[char.upper()]
            send_morse_code(code)
            time.sleep(dot_interval)  # Pause between characters

try:
    while True:
        user_input = input("Enter a message: ")
        send_message(user_input)
        time.sleep(char_interval)  # Pause between message repetitions

except KeyboardInterrupt:
    # Clean up GPIO pins
    GPIO.output(red_pin, GPIO.LOW)
    GPIO.output(green_pin, GPIO.LOW)
    GPIO.output(blue_pin, GPIO.LOW)
    GPIO.cleanup()
